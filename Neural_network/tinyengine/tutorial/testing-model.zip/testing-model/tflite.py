import sys
import os
import numpy as np
from PIL import Image 
import tensorflow as tf

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
from code_generator.TfliteConvertor import TfliteConvertor

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
from mcunet.mcunet.model_zoo import download_tflite

def convert_img_to_list(file_name):
    img = Image.open(f'./img_testing_gen/imgs/{file_name}').convert("RGB").resize((80, 80))
    img_arr = np.array(img).astype(np.int16) - 128
    return img_arr.flatten().tolist()
 
class IRDebugger:
    def __init__(self, model_path, layers):
        self.interpreter = tf.lite.Interpreter(model_path=model_path, experimental_preserve_all_tensors=True)
        self.interpreter.allocate_tensors()
        self.layers = layers
        self.tensor_details = self.interpreter.get_tensor_details()
        self.tensor_map = {t['index']: t for t in self.tensor_details}

    def debug(self, input_data):
        input_details = self.interpreter.get_input_details()

        for data, detail in zip(input_data, input_details):
            self.interpreter.set_tensor(detail["index"], data)

        self.interpreter.invoke()
        print("==== Layer-by-Layer Output ====")
        with open("layer_output.txt", "w") as f:
            np.set_printoptions(threshold=np.inf)
            for i, layer in enumerate(self.layers):
                # print(f"[Layer {i}] Op={type(layer).__name__} {layer.params}")  # Prints the class name (e.g., Conv2d, AvgPool2d)
                param = layer.params if hasattr(layer, 'params') else {}
                out_idx = param.get("output_idx")
                if i != 0:
                    continue
                if out_idx is None:
                    continue
                try:
                    out_tensor = self.interpreter.get_tensor(out_idx)
                    print(f"[Layer {i}] Op={param['op']}, Output Tensor Index={out_idx}, Shape={out_tensor.shape}")
                    # Optional: print actual values for small outputs
                    tensor_str = np.array2string(out_tensor, threshold=np.inf, separator=', ', max_line_width=1000)
                    f.write(f"[Layer {i}] Op={param['op']}, Shape={out_tensor.shape}\n")
                    # 
                    f.write(tensor_str + "\n\n")

                except Exception as e:
                    print(f"[Layer {i}] Failed to read tensor {out_idx}: {e}")
                    continue

tflite_path = download_tflite(net_id="mcunet-vww1")

parser = TfliteConvertor(tflite_path)
parser.parseOperatorInfo()

debugger = IRDebugger(model_path=tflite_path, layers=parser.layer)

file_name = 'ryan.png' # Specify the image file name here
object_name = 'Ryan'  # Specify the object name here

img_arr_1D = np.array(convert_img_to_list(file_name), dtype=np.int8)
input_data = img_arr_1D.reshape((1, 80, 80, 3))


debugger.debug([input_data])