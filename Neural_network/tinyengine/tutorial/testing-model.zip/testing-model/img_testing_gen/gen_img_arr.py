from PIL import Image 
import numpy as np
import os

if not os.path.exists('imgs'):
    os.makedirs('imgs')
    
"""
Image Requirement
- Image size: 80x80 pixels
- Image format: RGB (3 channels)
- Pixel valiues: int_16, range [-128, 127]
"""

file_name = 'ryan.png' # Specify the image file name here
object_name = 'ryan'  # Specify the object name here

def convert_img_to_list(file_name):
    img = Image.open(f'imgs/{file_name}').convert("RGB").resize((80, 80))
    img_arr = np.array(img).astype(np.int16) - 128
    return img_arr.flatten().tolist()

def write_img_to_file(file_name, object_name):
    img_arr_1D = convert_img_to_list(file_name)
    with open(f'imgs_arr/{object_name}.c', 'w') as f:
        f.write(f"const signed char {object_name}[] = {{\n")
        for i, val in enumerate(img_arr_1D):
            f.write(f"{val}")
            if i < len(img_arr_1D) - 1:
                f.write(", ")
            if (i + 1) % 48 == 0:
                f.write("\n")
            
        f.write("};\n")
    
if __name__ == "__main__":
    write_img_to_file(file_name, object_name)